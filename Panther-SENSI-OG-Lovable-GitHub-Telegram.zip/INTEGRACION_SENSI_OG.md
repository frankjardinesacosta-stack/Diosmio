# Panther + SENSI OG Telegram License Bot (paquete preparado)

Este paquete combina el proyecto fuente de Panther con el backend Node.js del bot SENSI OG. La app usa `/api/activate`; el backend incluye ese endpoint compatible y también `/api/public/validate`.

## Estado honesto

**No está conectado en producción todavía.** No puedo publicar el servidor ni compilar una IPA firmada desde este entorno. Para funcionar, debes desplegar el backend, poner los secretos privados en el host y actualizar la URL HTTPS en `ThreeOneOSFive/Info.plist`. El token de Telegram compartido en el chat debe revocarse en @BotFather y reemplazarse por uno nuevo; no está incluido en este ZIP.

## 1. Preparar credenciales

En el host del backend configura estas variables de entorno:

- `TELEGRAM_BOT_TOKEN`: token NUEVO de @BotFather. No lo incluyas en Git ni en la IPA.
- `ADMIN_TELEGRAM_ID`: tu ID personal de Telegram (no el número de ID del bot). Obténlo mediante un bot de información de usuario y compruébalo antes de configurar.
- `PUBLIC_BASE_URL`: URL HTTPS pública del servicio.
- `PORT`: el host normalmente lo asigna; usa `3000` localmente.
- `DATABASE_PATH`: por defecto `./data/sensi-keys.sqlite`. Asegura almacenamiento persistente para no perder licencias.

No se ha puesto ningún token real en los archivos.

## 2. Desplegar backend

Requisitos: Node.js 20+ y un host que soporte `better-sqlite3` o Docker con almacenamiento persistente.

Desde la carpeta `backend/`:

```bash
cp .env.example .env
# Edita .env localmente con el token NUEVO, tu ID personal y la URL HTTPS.
npm install
npm start
```

Para producción, usa Docker (`docker compose up -d --build`) y configura las variables como secretos del proveedor. No subas `.env` a GitHub. Comprueba `https://TU-DOMINIO/health` y que devuelva `{"ok":true,...}`.

## 3. Comandos del bot

En Telegram, abre `@SensiOG7_bot`:

- `/start`
- `/newkey 1d`
- `/newkey 7d`
- `/newkey 30d`
- `/newkey permanent`
- `/keys`
- `/revoke SENSI-...`

Solo el `ADMIN_TELEGRAM_ID` configurado puede usar los comandos administrativos.

## 4. Conectar Panther al servidor

Abre `ThreeOneOSFive/Info.plist` y reemplaza el valor de `PantherAPIBaseURL` por la URL HTTPS real del backend, sin barra final. Ejemplo: `https://sensi-api.tudominio.com`.

El backend devuelve a Panther el formato de activación que espera. La app envía `key` y `device_id`; la primera activación vincula la clave al dispositivo. Claves inválidas, vencidas, revocadas o vinculadas a otro dispositivo son rechazadas.

## 5. Prueba antes de distribuir

1. Abre el repositorio en Xcode en un Mac.
2. Compila y ejecuta la app con un servidor de pruebas.
3. Genera una key con el bot y prueba la activación.
4. Prueba `/revoke`, una key vencida y el uso de la misma key desde otro dispositivo.
5. Verifica también la sección de catálogo: el backend incluido administra licencias, pero no implementa los endpoints de catálogo/descarga de patches; esa función requiere un backend separado compatible.

## Seguridad

- El token compartido anteriormente debe revocarse.
- No se incluyó ningún token en el ZIP.
- No pongas secretos en Swift, `Info.plist`, GitHub commits ni dentro de la IPA.
- Un servidor debe ser accesible por HTTPS y la base de datos debe persistir.
- La validación del servidor es el control de licencia; ninguna app cliente puede proteger por sí sola una clave secreta.
