# Configuración SIN Render: Lovable + GitHub + Telegram

Este proyecto incluye el código iOS Panther y un backend Node.js de referencia. **GitHub solo guarda/sincroniza el código; no ejecuta el bot.** Para no usar Render, crea el backend en Lovable Cloud con una función HTTPS y una base de datos. No despliegues el servidor Node.js/SQLite incluido tal cual en Lovable: necesita adaptarse a funciones serverless y una base de datos gestionada.

## 1. Importar a Lovable
1. Sube el proyecto a un repositorio privado de GitHub.
2. En Lovable crea un proyecto y conecta GitHub desde Settings/Integrations/GitHub (si tu plan/interfaz lo permite).
3. Activa Lovable Cloud para disponer de funciones de servidor, secretos y base de datos.
4. Pega el prompt de abajo en el chat de Lovable.

## 2. Prompt para pegar en Lovable

Construye el backend real de licencias para mi bot de Telegram SENSI OG usando Lovable Cloud (funciones serverless + base de datos). No uses Render, Railway, Vercel ni otro host externo. Mantén los secretos únicamente en el servidor; nunca los pongas en el frontend ni en GitHub.

Requisitos:
- Crea una tabla `license_keys` con `key` única, `created_at`, `expires_at` nullable, `device_id` nullable y `revoked` boolean; aplica reglas de acceso para que el cliente público no pueda listar, crear, editar ni revocar licencias.
- Crea una función HTTPS de webhook para Telegram y configura el webhook usando el secreto `TELEGRAM_BOT_TOKEN` y el `ADMIN_TELEGRAM_ID` (ID personal numérico del administrador, no el ID del bot). Verifica el encabezado secreto del webhook. No uses polling.
- Solo el administrador puede ejecutar `/newkey 1d`, `/newkey 7d`, `/newkey 30d`, `/newkey permanent`, `/keys` y `/revoke <clave>`. Genera claves impredecibles con criptografía segura. Responde al administrador por Telegram y rechaza comandos de otros usuarios.
- Guarda los secretos como secrets/env vars de Lovable Cloud: `TELEGRAM_BOT_TOKEN`, `TELEGRAM_WEBHOOK_SECRET`, `ADMIN_TELEGRAM_ID`. Nunca muestres sus valores en logs, respuestas, código del cliente ni repositorio.
- Implementa un endpoint público para validar una clave y vincularla atómicamente al primer `device_id`; rechaza claves inexistentes, revocadas, vencidas o ligadas a otro dispositivo. No permitas cambiar el dispositivo después de vincularla.
- Conserva compatibilidad con las operaciones de la app: `POST /api/activate` y `POST /api/public/validate`, o crea rutas equivalentes y modifica el cliente Swift para llamar exactamente a las URLs desplegadas de Lovable Cloud. Devuelve respuestas JSON consistentes y errores sin filtrar datos sensibles.
- Añade una ruta de salud sencilla y pruebas para claves válidas, vencidas, revocadas, dispositivo incorrecto y usuario de Telegram no autorizado.
- No afirmes que el bot está conectado hasta que se haya guardado el token nuevo, publicado la función y configurado el webhook. Documenta la URL final y los pasos de prueba.

Antes de modificar código, revisa la estructura existente y explícame qué archivos cambiarás. No inventes una URL de producción: usa la URL real que muestre Lovable Cloud después de publicar.

## 3. Secretos y seguridad
- El token del bot compartido anteriormente debe considerarse comprometido: revócalo en `@BotFather` y usa el token nuevo solo en los secretos de Lovable Cloud.
- `ADMIN_TELEGRAM_ID` debe ser tu ID personal de Telegram. No uses el ID del bot.
- No pegues tokens en este archivo, en mensajes públicos, en el código Swift ni en GitHub.

## 4. Límites importantes
- El archivo `backend/` incluido es una implementación Node.js con Express y SQLite; **no es automáticamente compatible con funciones serverless**. Lovable debe recrear/adaptar el backend y la persistencia a Lovable Cloud.
- El catálogo y la descarga de parches (`POST /api/patches` y `POST /api/patches/{id}/download`) no quedan implementados por este backend de licencias. Si la app los necesita, hay que diseñarlos e implementarlos aparte con autorización y almacenamiento adecuados.
- GitHub no mantiene el bot encendido por sí solo. El servicio debe publicarse y el webhook debe quedar configurado en Telegram.
- Este ZIP no incluye una IPA firmada ni confirma que el backend haya sido desplegado o probado en producción.
