# SENSI OG — Telegram Key Bot + Validation API

Este ZIP crea un bot de Telegram que genera licencias y un servidor HTTP que las valida. **No modifica por sí solo una IPA compilada**: la app iOS debe enviar `key` y `device_id` al endpoint indicado más abajo.

## 1. Configuración segura

1. Crea un repositorio privado en GitHub y sube estos archivos.
2. En el servidor donde lo despliegues, crea `.env` a partir de `.env.example`.
3. En `TELEGRAM_BOT_TOKEN`, pega el token que te dio BotFather.
4. En `ADMIN_TELEGRAM_ID`, coloca TU ID personal de Telegram (no `8833269908`, que parece ser el ID del bot). Puedes obtenerlo hablando con `@userinfobot`.
5. Mantén `.env` fuera de Git. Nunca pongas el token en la IPA ni lo publiques.

## 2. Ejecutar con Docker

```bash
cp .env.example .env
# Edita .env con tus valores
docker compose up -d --build
```

El servidor debe estar publicado con HTTPS para que la aplicación pueda acceder desde internet. Configura `PUBLIC_BASE_URL` con el dominio HTTPS real de tu despliegue.

## 3. Comandos de Telegram

Abre `@SensiOG7_bot` y envía `/start`.

- `/newkey 1d` — key de 1 día
- `/newkey 7d` — key de 7 días
- `/newkey 30d` — key de 30 días
- `/newkey permanent` — key permanente
- `/keys` — últimas 30 keys
- `/revoke SENSI-...` — revocar una key

Los comandos administrativos solo funcionan para el ID personal configurado en `ADMIN_TELEGRAM_ID`.

## 4. API única de validación

Cuando el servidor esté desplegado, la dirección será:

`https://TU-DOMINIO/api/public/validate`

Método: `POST`  
Content-Type: `application/json`

Ejemplo:

```json
{
  "key": "SENSI-0123456789ABCDEF01234567",
  "device_id": "stable-device-identifier-from-your-app"
}
```

Respuesta correcta:

```json
{ "ok": true, "status": "active", "expires_at": 1893456000000 }
```

La primera validación vincula la key al `device_id`; posteriores validaciones deben usar el mismo identificador. El identificador debe ser estable y generado/administrado por la aplicación. No uses un valor vacío ni el ID de Telegram.

## 5. Estado y limitaciones

- `GET /health` permite comprobar si el servidor está activo.
- La base SQLite se guarda en `./data`; conserva el volumen Docker para no perder keys.
- Este es un backend inicial funcional, no una integración ya probada con la IPA existente.
- Para conectar la IPA, su código nativo debe hacer un POST JSON al endpoint con `key` y `device_id`, y gestionar `ok`, `error` y `expires_at`.
- El ZIP anterior solo contenía workflows y una IPA compilada; no incluía el proyecto Swift/Xcode necesario para modificar la pantalla de entrada.
